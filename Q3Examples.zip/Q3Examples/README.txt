This folder contains multiple replay files for A2Q3. The format is
discussed in A2Q3.
